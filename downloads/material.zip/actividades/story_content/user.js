function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6bviqHvMR1c":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

